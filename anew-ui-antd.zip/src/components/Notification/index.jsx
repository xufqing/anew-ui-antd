import normal from './normal';
import antdNotice from './antdNotice';

export { 
  normal, antdNotice
};
