import { createFromIconfontCN } from '@ant-design/icons'

export default createFromIconfontCN({
    // 可以管理自己的图标库
    scriptUrl: [
      '//at.alicdn.com/t/font_2150305_9zgvx16zmd.js',
    ],
  });