// @ts-nocheck
import { Plugin } from 'D:/anew-ui-antd/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange','dva','getInitialState','locale','locale','request',],
});

export { plugin };
