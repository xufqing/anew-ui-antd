// @ts-nocheck
import React from 'react';
import { ApplyPluginsType, dynamic } from 'D:/anew-ui-antd/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';
import LoadingComponent from '@/components/PageLoading/index';

export function getRoutes() {
  const routes = [
  {
    "path": "/user",
    "component": dynamic({ loader: () => import(/* webpackChunkName: 'layouts__UserLayout' */'D:/anew-ui-antd/src/layouts/UserLayout'), loading: LoadingComponent}),
    "routes": [
      {
        "name": "login",
        "path": "/user/login",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Auth__login' */'D:/anew-ui-antd/src/pages/Auth/login'), loading: LoadingComponent}),
        "exact": true
      }
    ]
  },
  {
    "path": "/",
    "component": dynamic({ loader: () => import(/* webpackChunkName: 'layouts__SecurityLayout' */'D:/anew-ui-antd/src/layouts/SecurityLayout'), loading: LoadingComponent}),
    "routes": [
      {
        "path": "/",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'layouts__BasicLayout' */'D:/anew-ui-antd/src/layouts/BasicLayout'), loading: LoadingComponent}),
        "authority": [
          "admin",
          "user"
        ],
        "routes": [
          {
            "path": "/",
            "redirect": "/workplace",
            "exact": true
          },
          {
            "path": "/workplace",
            "name": "workplace",
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__Dashboard' */'D:/anew-ui-antd/src/pages/Dashboard'), loading: LoadingComponent}),
            "exact": true
          },
          {
            "path": "/system",
            "name": "system",
            "authority": [
              "admin"
            ],
            "routes": [
              {
                "path": "/system/user",
                "name": "user",
                "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__System__user' */'D:/anew-ui-antd/src/pages/System/user'), loading: LoadingComponent}),
                "exact": true
              },
              {
                "path": "/system/dept",
                "name": "dept",
                "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__System__dept' */'D:/anew-ui-antd/src/pages/System/dept'), loading: LoadingComponent}),
                "exact": true
              },
              {
                "path": "/system/role",
                "name": "role",
                "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__System__role' */'D:/anew-ui-antd/src/pages/System/role'), loading: LoadingComponent}),
                "exact": true
              },
              {
                "path": "/system/menu",
                "name": "menu",
                "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__System__menu' */'D:/anew-ui-antd/src/pages/System/menu'), loading: LoadingComponent}),
                "exact": true
              },
              {
                "path": "/system/api",
                "name": "api",
                "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__System__api' */'D:/anew-ui-antd/src/pages/System/api'), loading: LoadingComponent}),
                "exact": true
              }
            ]
          },
          {
            "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'D:/anew-ui-antd/src/pages/404'), loading: LoadingComponent}),
            "exact": true
          }
        ]
      },
      {
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'D:/anew-ui-antd/src/pages/404'), loading: LoadingComponent}),
        "exact": true
      }
    ]
  },
  {
    "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'D:/anew-ui-antd/src/pages/404'), loading: LoadingComponent}),
    "exact": true
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
